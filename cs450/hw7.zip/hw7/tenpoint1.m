%Yongzuan Wu wu68 cs450 HW6 10.1 (a)
format long;
x = fzero(@shooting,0.5);

    
    
    
    
    
